package com.ubit.myapplication

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.ContactsContract
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import com.ubit.myapplication.databinding.ActivityMainBinding
class MainActivity : AppCompatActivity() {

    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)

        val navController = findNavController(R.id.nav_host_fragment_content_main)
        appBarConfiguration = AppBarConfiguration(navController.graph)
        setupActionBarWithNavController(navController, appBarConfiguration)

        binding.fab.setOnClickListener { view ->
            Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                .setAction("Action", null).show()
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        val navController = findNavController(R.id.nav_host_fragment_content_main)
        return navController.navigateUp(appBarConfiguration)
                || super.onSupportNavigateUp()
    }

    fun getContacts(view: View) {
        var intent = Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI)
        resultLauncher.launch(intent)

    }

//    var resultLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
//        if (result.resultCode == Activity.RESULT_OK) {
//            val data = result.data
//            if (data != null) {
//                val company = extractCompanyNameFromData(data)
//                if (company.isNotEmpty()) {
//                    println("Company Name: $company")
//                } else {
//                    println("Company Name not found in data.")
//                }
//            } else {
//                println("Result data is null.")
//            }
//        }
//    }
var resultLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
    if (result.resultCode == Activity.RESULT_OK) {
        val data = result.data
        if (data != null) {
            val company = extractCompanyNameFromData(data)
            if (company.isNotEmpty()) {
                println("Company Name: $company")
            } else {
                println("Company Name not found in data.")
            }
        } else {
            println("Result data is null.")
        }
    }
}

//    fun extractCompanyNameFromData(data: Intent): String {
//        // Replace "company" with the actual key used to store the company name in the Intent
//        val company = data.getStringExtra("company")
//        return company ?: ""
//    }
    //...................................................................
//fun extractCompanyNameFromData(data: Intent): String {
//    var companyName = ""
//
//    val contactUri = data.data
//    val contentResolver = contentResolver
//
//    // Query the contact data using the contact URI
//    val cursor = contentResolver.query(contactUri!!, null, null, null, null)
//
//    if (cursor != null && cursor.moveToFirst()) {
//        val contactId = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts._ID))
//
//        // Query the organization data for the given contact
//        val orgCursor = contentResolver.query(
//            ContactsContract.Data.CONTENT_URI,
//            null,
//            ContactsContract.Data.CONTACT_ID + " = ? AND " + ContactsContract.Data.MIMETYPE + " = ?",
//            arrayOf(contactId, ContactsContract.CommonDataKinds.Organization.CONTENT_ITEM_TYPE),
//            null
//        )
//
//        if (orgCursor != null && orgCursor.moveToFirst()) {
//            companyName = orgCursor.getString(
//                orgCursor.getColumnIndex(ContactsContract.CommonDataKinds.Organization.COMPANY)
//            )
//            orgCursor.close()
//        }
//
//        cursor.close()
//    }
//
//    return companyName
//}
fun extractCompanyNameFromData(data: Intent): String {
    var companyName = ""

    val contactUri = data.data
    val contentResolver = contentResolver

    // Query the organization data for the given contact
    val orgCursor = contentResolver.query(
        ContactsContract.Data.CONTENT_URI,
        null,
        ContactsContract.Data.CONTACT_ID + " = ? AND " + ContactsContract.Data.MIMETYPE + " = ?",
        arrayOf(contactUri?.lastPathSegment, ContactsContract.CommonDataKinds.Organization.CONTENT_ITEM_TYPE),
        null
    )

    if (orgCursor != null && orgCursor.moveToFirst()) {
        val companyColumnIndex = orgCursor.getColumnIndex(ContactsContract.CommonDataKinds.Organization.COMPANY)
        if (companyColumnIndex != -1) {
            companyName = orgCursor.getString(companyColumnIndex)
        }
        orgCursor.close()
    }

    return companyName
}




}